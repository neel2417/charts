function plotGraph() {
    var inputValue = parseFloat(document.getElementById("input-value").value);
    var maxValue = parseFloat(document.getElementById("max-value").value);

    // Check if Input Value is greater than Max Value
    if (inputValue > maxValue) {
        alert("Input Value cannot be greater than Max Value");
        return;
    }

    // Calculate percentages
    var inputPercentage = (inputValue / maxValue) * 100;
    var remainingPercentage = 100 - inputPercentage;

    // Plot the graph
    var graphElement = document.getElementById("graph");
    graphElement.innerHTML = ""; // Clear previous graph

    // Level 1: Vertical bar graph
    var barGraph = document.createElement("div");
    barGraph.className = "bar-graph";

    var inputBar = document.createElement("div");
    inputBar.className = "input-bar";
    inputBar.style.height = inputPercentage + "%";

    var remainingBar = document.createElement("div");
    remainingBar.className = "remaining-bar";
    remainingBar.style.height = remainingPercentage + "%";

    barGraph.appendChild(inputBar);
    barGraph.appendChild(remainingBar);

    graphElement.appendChild(barGraph);

    // Level 2: Pie chart
    var pieChart = document.createElement("div");
    pieChart.className = "pie-chart";

    var inputSlice = document.createElement("div");
    inputSlice.className = "input-slice";
    inputSlice.style.transform = "rotate(" + (inputPercentage * 3.6) + "deg)";

    var remainingSlice = document.createElement("div");
    remainingSlice.className = "remaining-slice";
    remainingSlice.style.transform = "rotate(" + (remainingPercentage * 3.6) + "deg)";

    pieChart.appendChild(inputSlice);
    pieChart.appendChild(remainingSlice);

    graphElement.appendChild(pieChart);

    // Level 3: Gradient in Vertical bar graph
    var gradientBarGraph = document.createElement("div");
    gradientBarGraph.className = "gradient-bar-graph";

    var gradientBar = document.createElement("div");
    gradientBar.className = "gradient-bar";
    gradientBar.style.background = "linear-gradient(to bottom, #75c1da " + inputPercentage + "%, #FFFFFF " + inputPercentage + "%)";

    gradientBarGraph.appendChild(gradientBar);

    graphElement.appendChild(gradientBarGraph);
}
